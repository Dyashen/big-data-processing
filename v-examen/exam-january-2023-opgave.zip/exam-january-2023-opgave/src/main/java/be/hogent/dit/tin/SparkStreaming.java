package be.hogent.dit.tin;

import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeoutException;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;


public class SparkStreaming {

	public static void main(String[] args) throws TimeoutException, StreamingQueryException {
		
		// Change folder to match location on your computer
        System.setProperty("hadoop.home.dir", "C:\\tmp\\winutils-extra\\hadoop");
		
        // 1: START YOUR CODE HERE
		SparkSession spark = null; // change this
		// 1: END YOUR CODE HERE
		
		Dataset<Row> sourceSystemsDf = createInMemoryDataset(spark);
		
		List<StructField>  fields = Arrays.asList(
				new StructField []  {
					DataTypes.createStructField("loglevel", DataTypes.StringType, false),
					DataTypes.createStructField("source", DataTypes.IntegerType, false),
					DataTypes.createStructField("day", DataTypes.StringType, false),
					DataTypes.createStructField("time", DataTypes.StringType, false),
					DataTypes.createStructField("message", DataTypes.StringType, true)					
				}
				); 
		
		
		
		// 3: START YOUR CODE HERE (read stream)
		
		
		// 3: END YOUR CODE HERE
		
		// 4: START YOUR CODE HERE (join dataframes)
		
				
		// 4: END YOUR CODE HERE

				
		// 5: START YOUR CODE HERE (Change loglevels to LOW and HIGH)
		
		// 5: END YOUR CODE HERE
		
		
		// 6: START YOUR CODE HERE (dayAndTime column)
		
		// 6: END YOUR CODE HERE
				
		// 7: START YOUR CODE HERE (aggregation)
		
		// 7: END YOUR CODE HERE
		
		// 8: START YOUR CODE HERE (ratio)
		
		// 8: END YOUR CODE HERE
		
		// 9: START YOUR CODE HERE (filter)
		
		// 9: END YOUR CODE HER
		
	
		// 10: START YOUR CODE HERE (show on console)
		
		// 10: END YOUR CODE HERE			
	}

	private static Dataset<Row> createInMemoryDataset(SparkSession spark) {
		
		List<StructField>  fields = Arrays.asList(
				new StructField []  {
					DataTypes.createStructField("source", DataTypes.IntegerType, false),
					DataTypes.createStructField("sourceString", DataTypes.StringType, false),
				}
				); 
		
		// 2: START YOUR CODE HERE
		
	    return null; // change this
		// 2: END YOUR CODE HERE
		
	}

}
