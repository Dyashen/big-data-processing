package be.hogent.dit.tin;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.api.java.UDF1;


public class WineSQL {

	public static void main(String[] args) {
				
		/*
		 * Part 1: 
		 */
		// 1: START YOUR CODE HERE
		
		// 1: END YOUR CODE HERE
		
		/*
		 * Part 2: Read in DataFrame
		 */
		// 2: START YOUR CODE HERE
		Dataset<Row> df = null; // change this
		// 2: END YOUR CODE HERE
		
		/*
		 * Part 3: Remove rows with missing values.
		 */
		// 3: START YOUR CODE HERE
		
		// 3: END YOUR CODE HERE
		
		/*
		 * Part 4: Remove rows with deviating pH
		 */
		// 4: START YOUR CODE HERE
		
		// 4: END YOUR CODE HERE
		
		/*
		 * Part 5: Report on wine quality and number of occurrences.
		 */
		showQualityReport(df);
		
		/*
		 * Part 6: Report on average alcohol percentage for each quality
		 */
		showAlcoholPercentageReport(df);
		
		/*
		 * Part 7: Register and use UDF
		 */
		// 7: START YOUR CODE HERE
				
		
		// 7: END YOUR CODE HERE
		
		showPHReport(df);
		
		
		/*
		 * Part 8: Save the DataFrame as a parquet file.
		 */
		// 8: START YOUR CODE HERE
		
		// 8: END YOUR CODE HERE
		
		

	}
	
	private static void showQualityReport(Dataset<Row> df) {
		// 5: START YOUR CODE HERE
		
		// 5: END YOUR CODE HERE
	}
	
	private static void showAlcoholPercentageReport(Dataset<Row> df) {
		// 6: START YOUR CODE HERE
		
		// 6: END YOUR CODE HERE

	}

	
	private static UDF1<Double, String> createUDF() {
		// 7: START YOUR CODE HERE
		return null; // change this
		// 7: END YOUR CODE HERE
	}
	
	private static void showPHReport(Dataset<Row> df) {
		// 7: START YOUR CODE HERE
		
		// 7: END YOUR CODE HERE
	}

	

}
