// Dylan Cluyse - G3C

package be.hogent.dit.tin;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SaveMode;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.api.java.UDF1;
import org.apache.spark.sql.types.DataTypes;

import static org.apache.spark.sql.functions.*;

public class WineSQL {
	// Dylan Cluyse - G3C
	static SparkSession spark;
	static final String INPUT_PATH = "src/main/resources/dd-wine.csv";
	static final String OUTPUT_PATH = "src/main/resources/dd-wine-transformed";

	public static void main(String[] args) {

		/*
		 * Part 1:
		 */
		// 1: START YOUR CODE HERE
		spark = SparkSession.builder().appName("WineSQL").master("local[*]").getOrCreate();
		spark.sparkContext().setLogLevel("ERROR"); // enkel de nodige tekst uitprinten
		// 1: END YOUR CODE HERE

		/*
		 * Part 2: Read in DataFrame
		 */
		// 2: START YOUR CODE HERE
		Dataset<Row> df = spark.read()
				.option("header", true)
				.option("delimiter", ";")
				.option("inferSchema", true)
				.csv(INPUT_PATH); // change this

		System.out.println(df.schema());
		// 2: END YOUR CODE HERE

		/*
		 * Part 3: Remove rows with missing values.
		 */
		// 3: START YOUR CODE HERE

		System.out.println("Het aantal voor het aanvullen is: " + df.count());
		df = df.where(not(col("alcohol").like("??")));
		System.out.println("Het aantal na het aanvullen is: " + df.count());
		// 3: END YOUR CODE HERE

		/*
		 * Part 4: Remove rows with deviating pH
		 */
		// 4: START YOUR CODE HERE
		System.out.println("Het aantal voor het verwijderen van de outliers is: " + df.count());
		df = df.where(col("pH").$greater$eq(2.5)
				.and(col("pH").$less$eq(4)));
		System.out.println("Het aantal na het verwijderen van de outliers is: " + df.count());
		// 4: END YOUR CODE HERE

		/*
		 * Part 5: Report on wine quality and number of occurrences.
		 */
		showQualityReport(df);

		/*
		 * Part 6: Report on average alcohol percentage for each quality
		 */
		showAlcoholPercentageReport(df);

		/*
		 * Part 7: Register and use UDF
		 */
		// 7: START YOUR CODE HERE
		spark.udf().register("convertPH", createUDF(), DataTypes.StringType);		
		// 7: END YOUR CODE HERE

		showPHReport(df);

		/*
		 * Part 8: Save the DataFrame as a parquet file.
		 */
		// 8: START YOUR CODE HERE
		df.write()
			.mode(SaveMode.Overwrite)
			.parquet(OUTPUT_PATH);
		// 8: END YOUR CODE HERE

	}

	private static void showQualityReport(Dataset<Row> df) {
		// 5: START YOUR CODE HERE
		df.groupBy(col("quality")).agg(count("quality").as("aantalVoorkomens"))
				.orderBy(desc("aantalVoorkomens"))
				.show();
		// 5: END YOUR CODE HERE
	}

	private static void showAlcoholPercentageReport(Dataset<Row> df) {
		// 6: START YOUR CODE HERE
		df.groupBy(col("quality"))
			.agg(bround(avg(col("alcohol").cast("double")), 3).as("average"), // gemiddelde berekenen
					bround(stddev(col("alcohol")),3).as("standard deviation"))
			.orderBy(desc("average"))
			.show();
		// 6: END YOUR CODE HERE
	}

	
	private static UDF1<Double, String> createUDF() {
		// 7: START YOUR CODE HERE
		return new UDF1<Double, String>() {
			public String call(Double pH) throws Exception {

				if (pH >= 3.25) {
					return "HIGH";
				} else if (pH >= 3.1) {
					return "MEDIUM";
				} else {
					return "LOW";
				}
			}
		};
		// 7: END YOUR CODE HERE
	}
	

	private static void showPHReport(Dataset<Row> df) {
		// 7: START YOUR CODE HERE
		df.withColumn("pH_CAT", call_udf("convertPH", col("pH")))
				.groupBy("pH_CAT")
				.agg(count("pH_CAT").as("aantalVoorkomensPerCat"))
				.show();
		// 7: END YOUR CODE HERE
	}

}
