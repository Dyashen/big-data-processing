// Dylan Cluyse - G3C
package be.hogent.dit.tin;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.RowFactory;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.streaming.OutputMode;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.streaming.Trigger;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructField;
import org.apache.spark.sql.types.StructType;

import static org.apache.spark.sql.functions.*;


public class SparkStreaming {
	// Dylan Cluyse - G3C
	static SparkSession spark;
	static final String INPUT_TOPIC = "";
	static final String CSV_TEST = "src/main/resources/logmessages.csv";
	static final String CSV_PATH = "src/main/resources/";
	static final String WATERMARK_DELAY = "1 minute";
	static final double TOLERANCE_PERCENTAGE = 0.15;

	public static void main(String[] args) throws TimeoutException, StreamingQueryException {
		
		// Change folder to match location on your computer
        System.setProperty("hadoop.home.dir", "C:\\tmp\\winutils-extra\\hadoop");
		
        // 1: START YOUR CODE HERE
        spark = SparkSession.builder().appName("SparkStreaming").master("local[*]").getOrCreate();
		spark.sparkContext().setLogLevel("ERROR");
		// 1: END YOUR CODE HERE
		
		Dataset<Row> sourceSystemsDf = createInMemoryDataset(spark);
		
		sourceSystemsDf.show();
		
		List<StructField>  fields = Arrays.asList(
				new StructField []  {
					DataTypes.createStructField("loglevel", DataTypes.StringType, false),
					DataTypes.createStructField("source", DataTypes.IntegerType, false),
					DataTypes.createStructField("day", DataTypes.StringType, false),
					DataTypes.createStructField("time", DataTypes.StringType, false),
					DataTypes.createStructField("message", DataTypes.StringType, true)					
				}
				); 
		
		
		
		// 3: START YOUR CODE HERE (read stream)
		StructType schema = DataTypes.createStructType(fields);
		
		// Om alle acties uit te testen.
		Dataset<Row> messagesTryOut = spark.read()
				.option("header", false)
				.schema(schema)
				.csv(CSV_TEST);

		messagesTryOut.show();
		
		Dataset<Row> messages = spark.readStream()
									.schema(schema)
									.option("header", false)
									.csv(CSV_PATH);
		messages.show();
		// 3: END YOUR CODE HERE
		
		// 4: START YOUR CODE HERE (join dataframes) 
		messages = sourceSystemsDf.join(messages, "source")
						.drop("source");
		// 4: END YOUR CODE HERE

				
		// 5: START YOUR CODE HERE (Change loglevels to LOW and HIGH)
		messages = messages.withColumn("loglevel", 
				when(col("loglevel").isin("ERROR", "FATAL"), "HIGH").otherwise("LOW"));
		// 5: END YOUR CODE HERE
		
		
		// 6: START YOUR CODE HERE (dayAndTime column)
		messages = messages.withColumn("dayAndTime", concat_ws(" ", col("day"), col("time"))
					.cast("TimeStamp"))
				.withWatermark("watermark",  WATERMARK_DELAY)
				.withColumn("window", window(col("dayAndTime"), "5 minutes"));
		// 6: END YOUR CODE HERE
				
		// 7: START YOUR CODE HERE (aggregation)
		messages = messages
				.withColumn("HIGH", when(col("loglevel").equalTo("HIGH"), 1).otherwise(0))
				.withColumn("LOW", when(col("loglevel").equalTo("LOW"), 1).otherwise(0))
				.groupBy(col("window"), col("sourceString"))
				.agg(sum("LOW").as("LOW"), sum("HIGH").as("HIGH"));
		// 7: END YOUR CODE HERE
		
		// 8: START YOUR CODE HERE (ratio)
		messages = messages.withColumn("ratio", bround(col("HIGH").divide(col("LOW")), 4));
		// 8: END YOUR CODE HERE
		
		// 9: START YOUR CODE HERE (filter)
		messages = messages.where(col("ratio")
				.$greater$eq(TOLERANCE_PERCENTAGE));
		// 9: END YOUR CODE HER
		
	
		// 10: START YOUR CODE HERE (show on console)
		StreamingQuery query = null;
		query = messages
				.writeStream()
				.format("console") // in console
				.outputMode(OutputMode.Append()) // nieuwe lijnen
				.trigger(Trigger.ProcessingTime(10, TimeUnit.SECONDS)) // iedere tien seconden
				.start();
		
		query.awaitTermination();
		// 10: END YOUR CODE HERE			
	}

	private static Dataset<Row> createInMemoryDataset(SparkSession spark) {
		
		List<StructField>  fields = Arrays.asList(
				new StructField []  {
					DataTypes.createStructField("source", DataTypes.IntegerType, false),
					DataTypes.createStructField("sourceString", DataTypes.StringType, false),
				}
				); 
		
		// 2: START YOUR CODE HERE
		StructType schema = DataTypes.createStructType(fields);
		
		List<Row> rows = new ArrayList<Row>();
		rows.add(RowFactory.create(0, "web"));
		rows.add(RowFactory.create(1, "e-mail"));
		rows.add(RowFactory.create(2, "database"));
		rows.add(RowFactory.create(3, "firewall"));
		rows.add(RowFactory.create(4, "ml-model"));
		
		return spark.createDataFrame(rows, schema);
		// 2: END YOUR CODE HERE
	}

}
